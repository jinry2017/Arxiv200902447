%%
% The codes refer to the calculations in the manuscript:
% Oceanic non-Kolmogorov optical turbulence and spherical wave propagation
% https://arxiv.org/abs/2009.02447
%%
clc;clear; close all;
%% 
n_a = 0.072; n_Q = 2.73;
syms c;
f_a = @(c)[1, 21.61.*c.^0.02, -18.18.*c.^0.04];
f_b = [0,0.61,0.55];
f_k = @(c)174.90.*c.^0.96;
f_c = @(pr)0.72*0.072^(4/3)/pr;
f_Ck = -gamma(11/6)*2^(2/3) / ( 4*pi*gamma(-1/3)*gamma(3/2) );

f_g = @(ky,c)...
    (1 + 21.61.*ky.^0.61.*c^0.02 - 18.18.*ky.^0.55.*c^0.04)...
    .*exp(-174.90.*ky.^2.*c^0.96);
f_A = @(alpha)gamma(alpha-1)*cos(pi*alpha/2)/(4*pi^2);

f_l0_c = @(a,b,k)a* k^(-b/2-2/3).*(b/3 - 2/9).*gamma(b/2 - 1/3);
f_l0 = @(yita,c)(pi*f_Ck*( f_l0_c(1,0,f_k(c)) + f_l0_c(21.61.*c.^0.02,0.61,f_k(c)) + f_l0_c(-18.18.*c.^0.04,0.55,f_k(c)) ) *yita^(-4/3))^(-3/4);

f_h_c = @(a,b,k,alpha)a* k^(-5/2-b/2+alpha/2) .* (3+b-alpha)./3 .* gamma( (3+b-alpha)./2 );
f_H = @(alpha,c,yita)(pi*f_A(alpha)*(f_l0(yita,c))^(5-alpha)*yita^(alpha-5)...
    * ( f_h_c(1,0,f_k(c),alpha) + f_h_c(21.61.*c.^0.02,0.61,f_k(c),alpha) + f_h_c(-18.18.*c.^0.04,0.55,f_k(c),alpha) ))^(1/(alpha-5));


f_Ci2 = @(belta, yips, hey) -belta * yips^(-1/3) * hey * gamma(-1/3) * gamma(3/2) / gamma(11/6) *2^(-2/3);
% f_Ci2 = @(belta, yips, hey)1;

f_fay = @(Pr,K,yita,alpha, belta, yips, hey)f_Ci2(belta, yips, hey) .* f_A(alpha)...
    .* K.^(-alpha) .* f_g(K.*yita./f_H(alpha,f_c(Pr),yita),f_c(Pr));

f_coh = @(ky,PrT,ch_max,ch_a,alphaT,yita) ch_max/2.*( 1 - tanh( (log10(ky) - 0.5.*(log10(f_H(alphaT,f_c(PrT),yita).*n_a) ...
    + log10(f_H(alphaT,f_c(PrT),yita).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )))...
    .*(2*ch_a/(log10(f_H(alphaT,f_c(PrT),yita).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )...
    - log10(f_H(alphaT,f_c(PrT),yita).*n_a))) ) );

f_fayTS = @(PrT, PrS, K, yita, alphaT, alphaS, ch_max, ch_a, belta, yips, heyT, heyS)...
    sqrt(f_fay(PrT,K,yita,alphaT, belta, yips, heyT).*...
    f_fay(PrS,K,yita,alphaS, belta, yips, heyS)).* f_coh(K.*yita,PrT,ch_max,ch_a,alphaT,yita);

% fnk_TS = @(PrTS,K,yita,alphaTS, belta, yips, heyTS)f_fay(PrTS,K,yita,alphaTS, belta, yips, heyTS);

fay_n0 = @(K,A,B,PrT,PrS,alphaT,alphaS,heyT,heyS,yita,yips,belta,ch_max,ch_a)...
    A^2.*f_fay(PrT,K,yita,alphaT,belta,yips,heyT) + B^2.* f_fay(PrS,K,yita,alphaS,belta,yips,heyS)...
    +2*A*B.*f_fayTS(PrT, PrS, K, yita, alphaT, alphaS, ch_max, ch_a, belta, yips, heyT, heyS);
fay_n1 = @(K,K0,A,B,PrT,PrS,alphaT,alphaS,heyT,heyS,yita,yips,belta,ch_max,ch_a)(1 - exp(-K.^2./K0^2))...
    .*fay_n0(K,A,B,PrT,PrS,alphaT,alphaS,heyT,heyS,yita,yips,belta,ch_max,ch_a);
%% 
n_Belta = 0.72;
% n_a = 0.072;
n_T = 15; n_S = 34.9; n_lumda = 532;
n_PrS = Y_Schmidt(n_T,'C',n_S,'ppt');
n_PrT = SW_Prandtl(n_T,'C',n_S,'ppt');
n_PrTS = 2*n_PrT*n_PrS/(n_PrT + n_PrS);
n_v = SW_Kviscosity(n_T,'C',n_S,'ppt');
n_Dt = n_v/n_PrT;
[n_A,n_B] = fun_AB(n_T,n_S,n_lumda);
n_yipsilon = 1E-3; n_yita = n_v^(3/4)/n_yipsilon^(1/4);
%% 
% omiga = -3;
% if abs(omiga)>=1
%     dr = abs(omiga) + (abs(omiga))^0.5 * (abs(omiga) - 1)^0.5;
% elseif abs(omiga)<0.5
%     dr = 0.15 * abs(omiga);
% else
%     dr = 1.85 * abs(omiga) - 0.85;
% end
n_H = -12;
n_hayT = 1E-5;
Alpha = gsw_alpha(n_S,n_T,0);
Beta = gsw_beta(n_S,n_T,0);  
n_hayS = n_hayT* c_t_s(n_H,1,Alpha,Beta);
%% coherence 
n_ch_max = 1; n_ch_a = 3; n_K0 = 4*pi/30;
n_rho = 1;

c_T = f_c(n_PrT)
c_S = f_c(n_PrS)
CT2 = f_Ci2(n_Belta, n_yipsilon, n_hayT)
CS2 = f_Ci2(n_Belta, n_yipsilon, n_hayS)
n_yita
n_A,n_B

%%
n0 = 1.34;
miu = 3; k = n0*2*pi/(532E-9); L = 15; 
%% 
fay_n1_BJ = @(K,alphaT,alphaS)fay_n1(K,n_K0,n_A,n_B,n_PrT,n_PrS,alphaT,alphaS,n_hayT,n_hayS,n_yita,n_yipsilon,n_Belta,n_ch_max,n_ch_a);

Dbj = @(n_rho,alphaT,alphaS)integral(@(K)fay_n1_BJ(K,alphaT,alphaS).*K.*(1 - besselj(0,K*n_rho)), 0,+Inf,'ArrayValued',true,'RelTol',1e-10,'AbsTol',1e-13).*(8*pi^2*k^2*L/n0^2);

s_int = 0;
rho_H = @(alphaT,alphaS)fsolve(@(rho)Dbj(rho,alphaT,alphaS) - 2,s_int);

FS = 15;

N_rhox = 201; rhox_max = 0.005;
rhox = (-rhox_max:2*rhox_max/(N_rhox-1):rhox_max);

[a_rhox,a_rhoy] = meshgrid(rhox,rhox);
rho = sqrt(a_rhox.^2 + a_rhoy.^2);
s_rho = reshape(rho,numel(rho),1);

% n_alphaT = 11/3,n_alphaS = 11/3;
n_alphaT = 11/3;n_alphaS = 11/3;
s_Dsp = Dbj(s_rho,n_alphaT,n_alphaS);
Dsp = reshape(s_Dsp,length(rhox),length(rhox));
figure('units','normalized','position',[0.2,0.2,0.25,0.40]);
surf(a_rhox*1E3,a_rhoy*1E3,Dsp);title('\it{D_{sp}}');view([0,0,1]);colorbar;
xlim([-rhox_max*1E3 rhox_max*1E3]);
ylim([-rhox_max*1E3 rhox_max*1E3]);
shading interp;
xlabel('\rho_{\it{x}}(mm)');
ylabel('\rho_{\it{y}}(mm)');
set(gca,'FontName','Times?New?Roman','FontSize',16,'LineWidth',2);
set(gca,'position',[0.22,0.25,0.57,0.57]);
save('4_0_a.mat','Dsp');

% n_alphaT = 14/3,n_alphaS = 11/3;
n_alphaT = 14/3;n_alphaS = 11/3;
s_Dsp = Dbj(s_rho,n_alphaT,n_alphaS);
Dsp = reshape(s_Dsp,length(rhox),length(rhox));
figure('units','normalized','position',[0.2,0.2,0.25,0.40]);
surf(a_rhox*1E3,a_rhoy*1E3,Dsp);title('\it{D_{sp}}');view([0,0,1]);colorbar;
xlim([-rhox_max*1E3 rhox_max*1E3]);
ylim([-rhox_max*1E3 rhox_max*1E3]);
shading interp;
xlabel('\rho_{\it{x}}(mm)');
ylabel('\rho_{\it{y}}(mm)');
set(gca,'FontName','Times?New?Roman','FontSize',16,'LineWidth',2);
set(gca,'position',[0.22,0.25,0.57,0.57]);
save('4_0_b.mat','Dsp');


% n_alphaT = 11/3,n_alphaS = 14/3;
n_alphaT = 11/3;n_alphaS = 14/3;
s_Dsp = Dbj(s_rho,n_alphaT,n_alphaS);
Dsp = reshape(s_Dsp,length(rhox),length(rhox));
figure('units','normalized','position',[0.2,0.2,0.25,0.40]);
surf(a_rhox*1E3,a_rhoy*1E3,Dsp);title('\it{D_{sp}}');view([0,0,1]);colorbar;
xlim([-rhox_max*1E3 rhox_max*1E3]);
ylim([-rhox_max*1E3 rhox_max*1E3]);
shading interp;
xlabel('\rho_{\it{x}}(mm)');
ylabel('\rho_{\it{y}}(mm)');
set(gca,'FontName','Times?New?Roman','FontSize',16,'LineWidth',2);
set(gca,'position',[0.22,0.25,0.57,0.57]);
save('4_0_c.mat','Dsp');

% n_alphaT = 14/3,n_alphaS = 14/3;
n_alphaT = 14/3;n_alphaS = 14/3;
s_Dsp = Dbj(s_rho,n_alphaT,n_alphaS);
Dsp = reshape(s_Dsp,length(rhox),length(rhox));
figure('units','normalized','position',[0.2,0.2,0.25,0.40]);
surf(a_rhox*1E3,a_rhoy*1E3,Dsp);title('\it{D_{sp}}');view([0,0,1]);colorbar;
xlim([-rhox_max*1E3 rhox_max*1E3]);
ylim([-rhox_max*1E3 rhox_max*1E3]);
shading interp;
xlabel('\rho_{\it{x}}(mm)');
ylabel('\rho_{\it{y}}(mm)');
set(gca,'FontName','Times?New?Roman','FontSize',16,'LineWidth',2);
set(gca,'position',[0.22,0.25,0.57,0.57]);
save('4_0_d.mat','Dsp');





