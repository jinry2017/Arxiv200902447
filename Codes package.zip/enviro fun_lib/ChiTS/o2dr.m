function [dr] = o2dr(omg)
%translate \omega to d_r
%
omega = abs(omg);
dr = omega.*1.85 - 0.85;
M1 = find(omega>=1); O1 = omega(M1);
M2 = find(omega<0.5); O2 = omega(M2);
dr(M1) = 01 + O1.^0.5 .* (O1 - 1).^0.5;
dr(M2) = O2.*0.15;

end

