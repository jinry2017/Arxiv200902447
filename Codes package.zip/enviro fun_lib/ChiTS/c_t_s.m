function [F1] = c_t_s(dT,dS,alpha,beta)
%translate dT,dS,alpha,beta to Chi_S/Chi_T
%
H = dT./dS; 
A = abs(alpha./beta./H); B = abs(H.*alpha./beta);
C = abs(beta./alpha./H);
F1 = A.*1.85 - 0.85./(abs(H).^2);
M1 = find(B>=1); O1A = A(M1); O1C = C(M1);
M2 = find(B<0.5); O2A = A(M2);
F1(M1) = O1A + O1A.* (1 - O1C).^0.5;
F1(M2) = O2A.*0.15;

end

