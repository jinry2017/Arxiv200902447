%%
% The codes refer to the calculations in the manuscript:
% Oceanic non-Kolmogorov optical turbulence and spherical wave propagation
% https://arxiv.org/abs/2009.02447
%%
clc;clear;close all;
%% 
n_Belta = 0.72;
n_a = 0.072;
n_Q = 2.35;
%% 
syms c;
f_a = @(c)[1, 21.61.*c.^0.02, -18.18.*c.^0.04];
f_b = [0,0.61,0.55];
f_k = @(c)174.90.*c.^0.96;
f_c = @(pr)0.72*0.072^(4/3)/pr;
f_Ck = -gamma(11/6)*2^(2/3) / ( 4*pi*gamma(-1/3)*gamma(3/2) );

f_g = @(ky,c)...
    (1 + 21.61.*ky.^0.61.*c^0.02 - 18.18.*ky.^0.55.*c^0.04)...
    .*exp(-174.90.*ky.^2.*c^0.96);
f_A = @(alpha)gamma(alpha-1)*cos(pi*alpha/2)/(4*pi^2);

f_l0_c = @(a,b,k)a* k^(-b/2-2/3).*(b/3 - 2/9).*gamma(b/2 - 1/3);
f_l0 = @(yita,c)(pi*f_Ck*( f_l0_c(1,0,f_k(c)) + f_l0_c(21.61.*c.^0.02,0.61,f_k(c)) + f_l0_c(-18.18.*c.^0.04,0.55,f_k(c)) ) *yita^(-4/3))^(-3/4);

f_h_c = @(a,b,k,alpha)a* k^(-5/2-b/2+alpha/2) .* (3+b-alpha)./3 .* gamma( (3+b-alpha)./2 );
f_H = @(alpha,c,yita)(pi*f_A(alpha)*(f_l0(yita,c))^(5-alpha)*yita^(alpha-5)...
    * ( f_h_c(1,0,f_k(c),alpha) + f_h_c(21.61.*c.^0.02,0.61,f_k(c),alpha) + f_h_c(-18.18.*c.^0.04,0.55,f_k(c),alpha) ))^(1/(alpha-5));


% f_Ci2 = @(belta, yips, hey) -belta * yips^(-1/3) * hey * gamma(-1/3) * gamma(3/2) / gamma(11/6) *2^(-2/3);
f_Ci2 = @(belta, yips, hey)1;

f_fay = @(Pr,K,yita,alpha, belta, yips, hey)f_Ci2(belta, yips, hey) .* f_A(alpha)...
    .* K.^(-alpha) .* f_g(K.*yita./f_H(alpha,f_c(Pr),yita),f_c(Pr));

% f_coh = @(ky,PrT,ch_max,ch_a,alphaT,yita) ch_max/2.*( 1 - tanh( (ky - 0.5.*f_H(alphaT,f_c(PrT),PrT).*(n_a + sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) ))...
%     .*(2*ch_a/(sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) - n_a )/f_H(alphaT,f_c(PrT),PrT)) ) );

% f_coh = @(ky,PrT,ch_max,ch_a,alphaT,yita) ch_max/2.*( 1 - tanh( (log10(ky) - 0.5.*(log10(f_H(alphaT,f_c(PrT),PrT).*n_a) ...
%     + log10(f_H(alphaT,f_c(PrT),PrT).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )))...
%     .*(2*ch_a/(log10(f_H(alphaT,f_c(PrT),PrT).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )...
%     - log10(f_H(alphaT,f_c(PrT),PrT).*n_a))) ) );
f_coh = @(ky,PrT,ch_max,ch_a,alphaT,yita) ch_max/2.*( 1 - tanh( (log10(ky) - 0.5.*(log10(f_H(alphaT,f_c(PrT),yita).*n_a) ...
    + log10(f_H(alphaT,f_c(PrT),yita).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )))...
    .*(2*ch_a/(log10(f_H(alphaT,f_c(PrT),yita).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )...
    - log10(f_H(alphaT,f_c(PrT),PrT).*n_a))) ) );


f_fayTS = @(PrT, PrS, K, yita, alphaT, alphaS, ch_max, ch_a, belta, yips, heyT, heyS)...
    sqrt(f_fay(PrT,K,yita,alphaT, belta, yips, heyT).*...
    f_fay(PrS,K,yita,alphaS, belta, yips, heyS)).* f_coh(K.*yita,PrT,ch_max,ch_a,alphaT,yita);

fnk_TS = @(PrTS,K,yita,alphaTS, belta, yips, heyTS)f_fay(PrTS,K,yita,alphaTS, belta, yips, heyTS);

%% 
n_T = 15; n_S = 34.9; n_lumda = 532;
n_PrS = Y_Schmidt(n_T,'C',n_S,'ppt');
n_PrT = SW_Prandtl(n_T,'C',n_S,'ppt');
n_PrTS = 2*n_PrT*n_PrS/(n_PrT + n_PrS);
n_v = SW_Kviscosity(n_T,'C',n_S,'ppt');
n_Dt = n_v/n_PrT;
[n_A,n_B] = fun_AB(n_T,n_S,n_lumda);
n_alphaT = 11/3; n_alphaS = n_alphaT; 
n_alphaTS = (n_alphaT + n_alphaS)/2;
n_yipsilon = 1E-4; n_yita = n_v^(3/4)/n_yipsilon^(1/4);

f_c(n_PrT)
f_c(n_PrS)

%% 
omiga = -3;
if abs(omiga)>=1
    dr = abs(omiga) + (abs(omiga))^0.5 * (abs(omiga) - 1)^0.5;
elseif abs(omiga)<0.5
    dr = 0.15 * abs(omiga);
else
    dr = 1.85 * abs(omiga) - 0.85;
end
n_hayT = 1E-5;
n_hayS = n_hayT* dr / omiga^2 * (n_A/n_B)^2;
n_hayTS = n_hayT*(-n_A/n_B) * (1 + dr)/(2*omiga);
%% coherence
n_ch_max = 1; n_ch_a1 = 4;  n_ch_a2 = 2; 
%% 
Kl = 10.^(-5:0.001:2) ./n_yita;
K = Kl';

Fay_T = f_fay(n_PrT,K, n_yita, n_alphaT, n_Belta, n_yipsilon, n_hayT);
Fay_S = f_fay(n_PrS,K, n_yita, n_alphaS, n_Belta, n_yipsilon, n_hayS);
% f_fayTS =       @(PrT,PrS,K,yita,alphaT,alphaS,miuT,miuS,k0,belta,yipsilon,hayT,hayS,ch_max,ch_a).
Fay_TSa1 = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, n_ch_a1, n_Belta, n_yipsilon, n_hayT, n_hayS);
Fay_TSa2 = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, n_ch_a2, n_Belta, n_yipsilon, n_hayT, n_hayS);
Fcoh_TSa1 = f_coh(K.*n_yita,n_PrT,n_ch_max,n_ch_a1,n_alphaT,n_yita);
Fcoh_TSa2 = f_coh(K.*n_yita,n_PrT,n_ch_max,n_ch_a2,n_alphaT,n_yita);

f_coh = @(ky,PrT,ch_max,ch_a,alphaT,yita)1;
f_fayTS = @(PrT, PrS, K, yita, alphaT, alphaS, ch_max, ch_a, belta, yips, heyT, heyS)...
    sqrt(f_fay(PrT,K,yita,alphaT, belta, yips, heyT).*...
    f_fay(PrS,K,yita,alphaS, belta, yips, heyS)).* f_coh(K.*yita,PrT,ch_max,ch_a,alphaT,yita);
Fay_TS1 = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, 1, n_Belta, n_yipsilon, n_hayT, n_hayS);

Fnk_TS = fnk_TS(n_PrTS,K,n_yita,n_alphaTS, n_Belta, n_yipsilon, n_hayTS);

%% 
%==========================================================================
H = figure('units','normalized','position',[0.2,0.22,0.35,0.35]);
% yyaxis left;
% plot(log10(Kl.*n_yita),Fay_T.*K.^(n_alphaT),'-r','linewidth',1); % Fay_T
hold on;
% plot(log10(Kl.*n_yita),Fay_S.*K.^(n_alphaS),'-b'); % Fay_S
plot(log10(Kl.*n_yita),Fay_TS1.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'-k','LineWidth',2); %F_TS_fc
plot(log10(Kl.*n_yita),Fay_TSa1.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--b','LineWidth',2); %F_TS_3
plot(log10(Kl.*n_yita),Fay_TSa2.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--r','LineWidth',2); %F_TS_8
plot(log10(Kl.*n_yita),Fnk_TS.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--k','LineWidth',2); %Fnk_TS
% legend('T','S','Fay_{TS}1','Fay_{TS}a1','Fay_{TS}a2','Fay_{TS}NK');

% yyaxis right;
% plot(log10(Kl.*n_yita),Fcoh_TSa1.*1,'-b'); %c_3
% plot(log10(Kl.*n_yita),Fcoh_TSa2.*1,'-r'); %c_8
% plot(log10(Kl.*n_yita),Fnk_TS./Fay_TS1,'-g'); %nk
hhh233 = (3*n_a^(4/3)/(22*n_Q*f_c(n_PrT)))^(0.5);

plot([log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)),log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita))],[0,0.6],'-b','linewidth',2);
plot([log10(hhh233*f_H(n_alphaT,f_c(n_PrT),n_yita)),log10(hhh233*f_H(n_alphaT,f_c(n_PrT),n_yita))],[0,0.6],'-r','linewidth',2);

ylim([0,0.18])
xlim([-2,1.5])
xlabel('\it log(\kappa\eta)'),ylabel('(\itC_T\rm^2\itC_S\rm^2)^{-1/2}\it\kappa\rm^{11/3}\it\Phi_{TS}');
set(gca,'FontSize',15,'LineWidth',2);
set(gca,'position',[0.20,0.24,0.75,0.7]);
% axis([-5,2,-20,10]);
% legend('T','S','Fay_{TS}1','Fay_{TS}a1','Fay_{TS}a2','Fay_{TS}NK','Fcoh_{TS}a1','Fcoh_{TS}a2')
% figure(2);
%==========================================================================
H = figure('units','normalized','position',[0.2,0.22,0.35,0.35]);
hold on;
plot(log10(Kl.*n_yita),Fay_TS1./Fay_TS1.*1,'-k','LineWidth',2); %c_3
plot(log10(Kl.*n_yita),Fay_TSa1./Fay_TS1,'--b','LineWidth',2); %c_3
plot(log10(Kl.*n_yita),Fay_TSa2./Fay_TS1,'--r','LineWidth',2); %c_8
plot(log10(Kl.*n_yita),Fnk_TS./Fay_TS1,'--k','LineWidth',2); %nk

plot([log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)),log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita))],[0,5],'-b','linewidth',2);
plot([log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)),log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita))],[0,5],'-r','linewidth',2);

ylim([0,1.2])
xlim([-2,1.5])
xlabel('\it log(\kappa\eta)'),ylabel('\it\gamma_{ST}');
set(gca,'FontSize',15,'LineWidth',2);
set(gca,'position',[0.20,0.24,0.75,0.7]);