%%
% The codes refer to the calculations in the manuscript:
% Oceanic non-Kolmogorov optical turbulence and spherical wave propagation
% https://arxiv.org/abs/2009.02447
%%
clc;clear;close all;
%% 
n_Belta = 0.72;
n_a = 0.072;
n_Q = 2.35;
%% 
syms c;
f_a = @(c)[1, 21.61.*c.^0.02, -18.18.*c.^0.04];
f_b = [0,0.61,0.55];
f_k = @(c)174.90.*c.^0.96;
f_c = @(pr)n_Belta*n_a^(4/3)/pr;
f_Ck = -gamma(11/6)*2^(2/3) / ( 4*pi*gamma(-1/3)*gamma(3/2) );

f_g = @(ky,c)...
    (1 + 21.61.*ky.^0.61.*c^0.02 - 18.18.*ky.^0.55.*c^0.04)...
    .*exp(-174.90.*ky.^2.*c^0.96);
f_A = @(alpha)gamma(alpha-1)*cos(pi*alpha/2)/(4*pi^2);

f_l0_c = @(a,b,k)a* k^(-b/2-2/3).*(b/3 - 2/9).*gamma(b/2 - 1/3);
f_l0 = @(yita,c)(pi*f_Ck*( f_l0_c(1,0,f_k(c)) + f_l0_c(21.61.*c.^0.02,0.61,f_k(c)) + f_l0_c(-18.18.*c.^0.04,0.55,f_k(c)) ) *yita^(-4/3))^(-3/4);

f_h_c = @(a,b,k,alpha)a* k^(-5/2-b/2+alpha/2) .* (3+b-alpha)./3 .* gamma( (3+b-alpha)./2 );
f_H = @(alpha,c,yita)(pi*f_A(alpha)*(f_l0(yita,c))^(5-alpha)*yita^(alpha-5)...
    * ( f_h_c(1,0,f_k(c),alpha) + f_h_c(21.61.*c.^0.02,0.61,f_k(c),alpha) + f_h_c(-18.18.*c.^0.04,0.55,f_k(c),alpha) ))^(1/(alpha-5));


% f_Ci2 = @(belta, yips, hey) -belta * yips^(-1/3) * hey * gamma(-1/3) * gamma(3/2) / gamma(11/6) *2^(-2/3);
f_Ci2 = @(belta, yips, hey)1;

f_fay = @(Pr,K,yita,alpha, belta, yips, hey)f_Ci2(belta, yips, hey) .* f_A(alpha)...
    .* K.^(-alpha) .* f_g(K.*yita./f_H(alpha,f_c(Pr),yita),f_c(Pr));

% f_coh = @(ky,PrT,ch_max,ch_a,alphaT,yita) ch_max/2.*( 1 - tanh( (log10(ky) - 0.5.*(log10(f_H(alphaT,f_c(PrT),PrT).*n_a) ...
%     + log10(f_H(alphaT,f_c(PrT),PrT).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )))...
%     .*(2*ch_a/(log10(f_H(alphaT,f_c(PrT),PrT).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )...
%     - log10(f_H(alphaT,f_c(PrT),PrT).*n_a))) ) );
f_coh = @(ky,PrT,ch_max,ch_a,alphaT,yita) ch_max/2.*( 1 - tanh( (log10(ky) - 0.5.*(log10(f_H(alphaT,f_c(PrT),yita).*n_a) ...
    + log10(f_H(alphaT,f_c(PrT),yita).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )))...
    .*(2*ch_a/(log10(f_H(alphaT,f_c(PrT),yita).*sqrt( 3*n_a^(4/3)/(22*n_Q*f_c(PrT)) ) )...
    - log10(f_H(alphaT,f_c(PrT),yita).*n_a))) ) );

f_fayTS = @(PrT, PrS, K, yita, alphaT, alphaS, ch_max, ch_a, belta, yips, heyT, heyS)...
    sqrt(f_fay(PrT,K,yita,alphaT, belta, yips, heyT).*...
    f_fay(PrS,K,yita,alphaS, belta, yips, heyS)).* f_coh(K.*yita,PrT,ch_max,ch_a,alphaT,yita);

fnk_TS = @(PrTS,K,yita,alphaTS, belta, yips, heyTS)f_fay(PrTS,K,yita,alphaTS, belta, yips, heyTS);

%% 
n_T = 15; n_S = 34.9; n_lumda = 532;
n_PrS = Y_Schmidt(n_T,'C',n_S,'ppt');
n_PrT = SW_Prandtl(n_T,'C',n_S,'ppt');
n_v = SW_Kviscosity(n_T,'C',n_S,'ppt');
n_Dt = n_v/n_PrT;
[n_A,n_B] = fun_AB(n_T,n_S,n_lumda);
A_alphaT = [11,12.5,14]./3; 
A_alphaS = [11,12.5,14]./3; 
n_yipsilon = 1E-4; n_yita = n_v^(3/4)/n_yipsilon^(1/4);
%% 
omiga = -3;
if abs(omiga)>=1
    dr = abs(omiga) + (abs(omiga))^0.5 * (abs(omiga) - 1)^0.5;
elseif abs(omiga)<0.5
    dr = 0.15 * abs(omiga);
else
    dr = 1.85 * abs(omiga) - 0.85;
end
n_hayT = 1E-5;
n_hayS = n_hayT* dr / omiga^2 * (n_A/n_B)^2;
n_hayTS = n_hayT*(-n_A/n_B) * (1 + dr)/(2*omiga);
%% coherence
n_ch_max = 1; n_ch_a1 = 3;
%% 
Kl = 10.^(-5:0.001:2) ./n_yita;
K = Kl';

f_fayTS_fc = @(PrT, PrS, K, yita, alphaT, alphaS, ch_max, ch_a, belta, yips, heyT, heyS)...
    sqrt(f_fay(PrT,K,yita,alphaT, belta, yips, heyT).*...
    f_fay(PrS,K,yita,alphaS, belta, yips, heyS)).* 1;

%% 
ymmm = 0.2;
xlima = [0.5,4];
ylima = [0 0.4];
%==========================================================================
H = figure('units','normalized','position',[0.2,0.22,0.25,0.3]);
% title('\alpha_T = 14/3; \alpha_S = 11/3');
n_alphaT = 14/3;
n_alphaS = A_alphaS(1);
Fay_TSa = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, n_ch_a1, n_Belta, n_yipsilon, n_hayT, n_hayS);
Fay_TS = f_fayTS_fc(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, 3, n_Belta, n_yipsilon, n_hayT, n_hayS);
hold on;
plot(log10(Kl),Fay_TSa.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--k','linewidth',2); %F_TS_3
plot(log10(Kl),Fay_TS.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'-k','linewidth',2); %F_TS_3

plot([log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-b','linewidth',2);
plot([log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-r','linewidth',2);

ylim(ylima);
xlim(xlima);
xlabel('\itlog\rm(\it\kappa\rm)');
ylabel('\itf\rm(\it\kappa\rm)');
set(gca,'FontSize',15,'LineWidth',2);
set(gca,'position',[0.18,0.3,0.67,0.65]);
savefig(H,'Section_2_2_4_a.fig');print(gcf, '-depsc','2_2_4_a.eps');
%==========================================================================
H = figure('units','normalized','position',[0.2,0.22,0.25,0.3]);
% title('\alpha_T = 14/3; \alpha_S = 12.5/3');
n_alphaT = 14/3;
n_alphaS = A_alphaS(2);
Fay_TSa = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, n_ch_a1, n_Belta, n_yipsilon, n_hayT, n_hayS);
Fay_TS = f_fayTS_fc(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, 3, n_Belta, n_yipsilon, n_hayT, n_hayS);
hold on;
plot(log10(Kl),Fay_TSa.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--k','linewidth',2); %F_TS_3
plot(log10(Kl),Fay_TS.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'-k','linewidth',2); %F_TS_3

plot([log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-b','linewidth',2);
plot([log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-r','linewidth',2);

ylim(ylima);
xlim(xlima);
xlabel('\itlog\rm(\it\kappa\rm)');
ylabel('\itf\rm(\it\kappa\rm)');
set(gca,'FontSize',15,'LineWidth',2);
set(gca,'position',[0.18,0.3,0.67,0.65]);
savefig(H,'Section_2_2_4_b.fig');print(gcf, '-depsc','2_2_4_b.eps')

%==========================================================================
H = figure('units','normalized','position',[0.2,0.22,0.25,0.3]);
% title('\alpha_T = 14/3; \alpha_S = 14/3');
n_alphaT = 14/3;
n_alphaS = A_alphaS(3);
Fay_TSa = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, n_ch_a1, n_Belta, n_yipsilon, n_hayT, n_hayS);
Fay_TS = f_fayTS_fc(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, 3, n_Belta, n_yipsilon, n_hayT, n_hayS);
hold on;
plot(log10(Kl),Fay_TSa.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--k','linewidth',2); %F_TS_3
plot(log10(Kl),Fay_TS.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'-k','linewidth',2); %F_TS_3

plot([log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-b','linewidth',2);
plot([log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-r','linewidth',2);

ylim(ylima);
xlim(xlima);
xlabel('\itlog\rm(\it\kappa\rm)');
ylabel('\itf\rm(\it\kappa\rm)');
set(gca,'FontSize',15,'LineWidth',2);
set(gca,'position',[0.18,0.3,0.67,0.65]);
savefig(H,'Section_2_2_4_c.fig');print(gcf, '-depsc','2_2_4_c.eps')

%==========================================================================
H = figure('units','normalized','position',[0.2,0.22,0.25,0.3]);
% title('\alpha_T = 11/3; \alpha_S = 12/3');
n_alphaT = A_alphaT(1);
n_alphaS = 12/3;
Fay_TSa = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, n_ch_a1, n_Belta, n_yipsilon, n_hayT, n_hayS);
Fay_TS = f_fayTS_fc(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, 3, n_Belta, n_yipsilon, n_hayT, n_hayS);
hold on;
plot(log10(Kl),Fay_TSa.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--k','linewidth',2); %F_TS_3
plot(log10(Kl),Fay_TS.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'-k','linewidth',2); %F_TS_3

plot([log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-b','linewidth',2);
plot([log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-r','linewidth',2);

ylim(ylima);
xlim(xlima);
xlabel('\itlog\rm(\it\kappa\rm)');
ylabel('\itf\rm(\it\kappa\rm)');
set(gca,'FontSize',15,'LineWidth',2);
set(gca,'position',[0.18,0.3,0.67,0.65]);
savefig(H,'Section_2_2_4_d.fig');print(gcf, '-depsc','2_2_4_d.eps')

%==========================================================================
H = figure('units','normalized','position',[0.2,0.22,0.25,0.3]);
% title('\alpha_T = 12.5/3; \alpha_S = 12/3');
n_alphaT = A_alphaT(2);
n_alphaS = 12/3;
Fay_TSa = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, n_ch_a1, n_Belta, n_yipsilon, n_hayT, n_hayS);
Fay_TS = f_fayTS_fc(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, 3, n_Belta, n_yipsilon, n_hayT, n_hayS);
hold on;
plot(log10(Kl),Fay_TSa.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--k','linewidth',2); %F_TS_3
plot(log10(Kl),Fay_TS.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'-k','linewidth',2); %F_TS_3

plot([log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-b','linewidth',2);
plot([log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-r','linewidth',2);

ylim(ylima);
xlim(xlima);
xlabel('\itlog\rm(\it\kappa\rm)');
ylabel('\itf\rm(\it\kappa\rm)');
set(gca,'FontSize',15,'LineWidth',2);
set(gca,'position',[0.18,0.3,0.67,0.65]);
savefig(H,'Section_2_2_4_e.fig');print(gcf, '-depsc','2_2_4_e.eps')

%==========================================================================
H = figure('units','normalized','position',[0.2,0.22,0.25,0.3]);
% title('\alpha_T = 14/3; \alpha_S = 12/3');
n_alphaT = A_alphaT(3);
n_alphaS = 12/3;
Fay_TSa = f_fayTS(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, n_ch_a1, n_Belta, n_yipsilon, n_hayT, n_hayS);
Fay_TS = f_fayTS_fc(n_PrT,n_PrS,K,n_yita,n_alphaT,n_alphaS,n_ch_max, 3, n_Belta, n_yipsilon, n_hayT, n_hayS);
hold on;
plot(log10(Kl),Fay_TSa.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'--k','linewidth',2); %F_TS_3
plot(log10(Kl),Fay_TS.*K.^(n_alphaT/2).*K.^(n_alphaS/2),'-k','linewidth',2); %F_TS_3

plot([log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(n_a*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-b','linewidth',2);
plot([log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita),log10(sqrt( 3*n_PrT/(22*n_Belta*n_Q) )*f_H(n_alphaT,f_c(n_PrT),n_yita)./n_yita)],[0,5],'-r','linewidth',2);

ylim(ylima);
xlim(xlima);
xlabel('\itlog\rm(\it\kappa\rm)');
ylabel('\itf\rm(\it\kappa\rm)');
set(gca,'FontSize',15,'LineWidth',2);
set(gca,'position',[0.18,0.3,0.67,0.65]);
savefig(H,'Section_2_2_4_f.fig');print(gcf, '-depsc','2_2_4_f.eps')


