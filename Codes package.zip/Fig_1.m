%%
% The codes refer to the calculations in the manuscript:
% Oceanic non-Kolmogorov optical turbulence and spherical wave propagation
% https://arxiv.org/abs/2009.02447
%%
clc;clear all; close all;
%% 
syms c;
f_a = @(c)[1, 21.61.*c.^0.02, -18.18.*c.^0.04];
f_b = [0,0.61,0.55];
f_k = @(c)174.90.*c.^0.96;
f_c = @(pr)0.72*0.072^(4/3)/pr;
f_Ck = -gamma(11/6)*2^(2/3) / ( 4*pi*gamma(-1/3)*gamma(3/2) );

f_l0_c = @(a,b,k)a* k^(-b/2-2/3).*(b/3 - 2/9).*gamma(b/2 - 1/3);
% f_l0_c(1,0,f_k(c)) + f_l0_c(21.61.*c.^0.02,0.61,f_k(c)) + f_l0_c(-18.18.*c.^0.04,0.55,f_k(c))
f_l0 = @(yita,c)(pi*f_Ck*( f_l0_c(1,0,f_k(c)) + f_l0_c(21.61.*c.^0.02,0.61,f_k(c)) + f_l0_c(-18.18.*c.^0.04,0.55,f_k(c)) ) *yita^(-4/3))^(-3/4);

f_A = @(alpha)gamma(alpha-1)*cos(pi*alpha/2)/(4*pi^2);

f_h_c = @(a,b,k,alpha)a* k^(-5/2-b/2+alpha/2) .* (3+b-alpha)./3 .* gamma( (3+b-alpha)./2 );
% f_h_c(1,0,f_k(c),alpha) + f_h_c(21.61.*c.^0.02,0.61,f_k(c),alpha) + f_h_c(-18.18.*c.^0.04,0.55,f_k(c),alpha)
f_h = @(alpha,yita,c)(pi*f_A(alpha)*(f_l0(yita,c))^(5-alpha)*yita^(alpha-5)...
    * ( f_h_c(1,0,f_k(c),alpha) + f_h_c(21.61.*c.^0.02,0.61,f_k(c),alpha) + f_h_c(-18.18.*c.^0.04,0.55,f_k(c),alpha) ))^(1/(alpha-5));

f_D_c = @(a,b,k,alpha,yita,R,c)a.* k.^(-3/2-b./2+alpha/2).*gamma( (3+b-alpha)./2 ).*(1 - hypergeom((3+b-alpha)/2,3/2,-(f_h(alpha,yita,c))^2*R^2/(4*k*yita^2)));
% f_D_c(1,0,f_k(c),alpha,yita,R,c) + f_D_c(21.61.*c.^0.02,0.61,f_k(c),alpha,yita,R,c) + f_D_c(-18.18.*c.^0.04,0.55,f_k(c),alpha,yita,R,c)
f_D = @(alpha,yita,c,Ci2,R)4*pi*Ci2*f_A(alpha)*(yita/f_h(alpha,yita,c))^(alpha-3)...
    .* (f_D_c(1,0,f_k(c),alpha,yita,R,c) + f_D_c(21.61.*c.^0.02,0.61,f_k(c),alpha,yita,R,c) + f_D_c(-18.18.*c.^0.04,0.55,f_k(c),alpha,yita,R,c));

%% fig 1
f_Analy1 = @(alpha,yita,c,Ci2,R)f_D(alpha,yita,c,Ci2,R)/(f_l0(yita,c))^(alpha-5)/R^2/Ci2; %�ڳ߶ȼ���
f_Analy2 = @(alpha,yita,c,Ci2,R)f_D(alpha,yita,c,Ci2,R)/R^(alpha-3)/Ci2; %��߶ȼ���

a_R = 10.^(-8:0.1:4); n_yita = 3.6E-4; n_Pr = 700; n_Ci2 = 1;
Data2_1 = double(zeros(length(a_R),3));
Data2_2 = double(zeros(length(a_R),3));

n_alpha = 11/3; 
for i = 1:length(a_R)
    Data2_1(i,1) = f_Analy1(n_alpha,n_yita,f_c(n_Pr),n_Ci2,a_R(i));
    Data2_2(i,1) = f_Analy2(n_alpha,n_yita,f_c(n_Pr),n_Ci2,a_R(i));
end
n_alpha = 12.5/3; 
for i = 1:length(a_R)
    Data2_1(i,2) = f_Analy1(n_alpha,n_yita,f_c(n_Pr),n_Ci2,a_R(i));
    Data2_2(i,2) = f_Analy2(n_alpha,n_yita,f_c(n_Pr),n_Ci2,a_R(i));
end
n_alpha = 14/3; 
for i = 1:length(a_R)
    Data2_1(i,3) = f_Analy1(n_alpha,n_yita,f_c(n_Pr),n_Ci2,a_R(i));
    Data2_2(i,3) = f_Analy2(n_alpha,n_yita,f_c(n_Pr),n_Ci2,a_R(i));
end
figure(2);
plot(log10(a_R'),[Data2_1,Data2_2]);
legend('\alpha = 11/3 F_1','\alpha = 12.5/3 F_1','\alpha = 14/3 F_1'...
    ,'\alpha = 11/3 F_2','\alpha = 12.5/3 F_2','\alpha = 14/3 F_2');
% Data_save = [log10(a_R'),Data2_1,Data2_2];
% save('Section_2_1_191225_0.mat','Data_save');
xlabel('\it{log}\rm(\itR\rm)');ylabel('\itF\rm_1 or \itF\rm_2');